INSERT INTO team (TeamID, ManagerID, GroupID, TeamName, TeamNationality)
VALUES 
(1, 1, 'B', 'Bayern Munich', 'Germany'),
(2, 2, 'B', 'Paris Saint-Germain', 'France'), 
(3, 3, 'B', 'Anderlecht', 'Belgium'),
(4, 4, 'B', 'Celtic ', 'Scotland'),
(5, 5, 'C', 'Chelsea', 'England'),
(6, 6, 'C', 'Atletico Madrid', 'Spain'),
(7, 7, 'C', 'Roma', 'Italy'),
(8, 8,'C', 'Qarabag', 'Azerbaijan'),
(9, 9, 'E', 'Spartak Moscow', 'Russia'),
(10, 10, 'E', 'Sevilla', 'Andalusia'),
(11, 11, 'E', 'Liverpool', 'England'),
(12, 12, 'E', 'Maribor', 'Slovenia'),
(13, 13, 'H', 'Real Madrid', 'Spain'),
(14, 14, 'H', 'Dortmund', 'Germany'),
(15, 15, 'H', 'Tottenham', 'England'),
(16, 16, 'H', 'APOEL', 'Cyprus');