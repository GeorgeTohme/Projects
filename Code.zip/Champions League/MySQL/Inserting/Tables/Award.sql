INSERT INTO award
VALUES
(1, NULL, 'Top Scorer'),
(2, NULL, 'Most Assists'),
(3,	216, 'Player of the Tournament'),
(4,	13, 'Manager of the Tournament');