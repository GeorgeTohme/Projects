INSERT INTO person_type
VALUES 
(1, 'Player'),
(2, 'Manager'),
(3, 'Referee');
