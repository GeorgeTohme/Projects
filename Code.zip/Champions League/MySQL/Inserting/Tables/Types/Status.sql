INSERT INTO status
VALUES 
(1, 'Available'),
(2, 'Injured'),
(3, 'Suspended');
