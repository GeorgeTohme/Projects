INSERT INTO position
VALUES 
(1, 'GoalKeeper'),
(2, 'Defender'),
(3, 'Midfielder'),
(4, 'Forward');
