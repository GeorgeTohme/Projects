INSERT INTO match_type
VALUES 
(1, 'Group Stage'),
(2, 'Round of 16'),
(3, 'Quarter-final'),
(4, 'Semi-final'),
(5, 'Final');
