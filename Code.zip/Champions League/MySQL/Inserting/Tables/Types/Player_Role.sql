INSERT INTO player_role
VALUES 
(1, 'Starter'),
(2, 'Substitute'),
(3, 'Reserve');
