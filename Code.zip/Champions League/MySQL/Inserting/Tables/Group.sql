INSERT INTO `group` (GroupID)
VALUES ('B'), ('C'), ('E'), ('H');

