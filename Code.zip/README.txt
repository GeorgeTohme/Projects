Description for each project:
- Phonebook: mini-project I coded after my first semester for fun (1st term)
- Champions League: a database + GUI to query the database (4th term)
- Student Courses and Grades: Website, more info in README file inside the project (5th term)